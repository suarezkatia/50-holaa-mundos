Typescript
console.log('Hola Mundo');
