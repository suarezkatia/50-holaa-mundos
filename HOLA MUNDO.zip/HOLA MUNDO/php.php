php
<?php echo 'Hola Mundo'; ?>
