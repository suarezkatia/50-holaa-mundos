erlang
io:fwrite("Hola Mundo\n").
