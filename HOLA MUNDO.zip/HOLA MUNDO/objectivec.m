objectivec
#import <Foundation/Foundation.h>
int main() {
   NSLog(@"Hola Mundo");
   return 0;
}
