haskell
main = putStrLn "Hola Mundo"