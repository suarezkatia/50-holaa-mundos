cpp
#include <iostream>
int main() {
  std::cout << "Hola Mundo";
  return 0;
}
