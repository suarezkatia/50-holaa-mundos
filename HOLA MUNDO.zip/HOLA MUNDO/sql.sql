*SQL (PostgreSQL)*
sql
SELECT 'Hola Mundo';

