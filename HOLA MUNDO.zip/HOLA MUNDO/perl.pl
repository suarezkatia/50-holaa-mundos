perl
print "Hola Mundo\n";