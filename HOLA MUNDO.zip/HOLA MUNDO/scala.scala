scala
object HelloWorld extends App {
  println("Hola Mundo")
}