swift
import Swift
print("Hola Mundo")
