vbnet
Module Module1
    Sub Main()
        Console.WriteLine("Hola Mundo")
    End Sub 
End Module
