
groovy
println 'Hola Mundo'